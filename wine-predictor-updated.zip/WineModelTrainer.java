
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.ml.classification.LogisticRegression;
import org.apache.spark.ml.classification.LogisticRegressionModel;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.ml.linalg.Vector;
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator;
import org.apache.spark.sql.*;

public class WineModelTrainer {
    public static void main(String[] args) {
        SparkSession spark = SparkSession.builder()
                .appName("Wine Quality Trainer")
                .master("local[*]")
                .getOrCreate();

        Dataset<Row> data = spark.read()
                .format("csv")
                .option("header", "true")
                .option("inferSchema", "true")
                .load("TrainingDataset.csv");

        String[] featureCols = new String[]{
                "fixed acidity", "volatile acidity", "citric acid", "residual sugar", "chlorides",
                "free sulfur dioxide", "total sulfur dioxide", "density", "pH", "sulphates", "alcohol"
        };

        VectorAssembler assembler = new VectorAssembler()
                .setInputCols(featureCols)
                .setOutputCol("features");

        Dataset<Row> featureData = assembler.transform(data).select("features", "quality");
        Dataset<Row> finalData = featureData.withColumn("label", featureData.col("quality").cast("double"));

        LogisticRegression lr = new LogisticRegression();
        LogisticRegressionModel model = lr.fit(finalData);

        model.save("wineModel");

        spark.stop();
    }
}
