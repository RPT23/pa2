
import org.apache.spark.ml.classification.LogisticRegressionModel;
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.sql.*;

public class WineModelValidator {
    public static void main(String[] args) {
        SparkSession spark = SparkSession.builder()
                .appName("Wine Model Validator")
                .master("local[*]")
                .getOrCreate();

        Dataset<Row> data = spark.read()
                .format("csv")
                .option("header", "true")
                .option("inferSchema", "true")
                .load("ValidationDataset.csv");

        String[] featureCols = new String[]{
                "fixed acidity", "volatile acidity", "citric acid", "residual sugar", "chlorides",
                "free sulfur dioxide", "total sulfur dioxide", "density", "pH", "sulphates", "alcohol"
        };

        VectorAssembler assembler = new VectorAssembler()
                .setInputCols(featureCols)
                .setOutputCol("features");

        Dataset<Row> featureData = assembler.transform(data).select("features", "quality");
        Dataset<Row> finalData = featureData.withColumn("label", featureData.col("quality").cast("double"));

        LogisticRegressionModel model = LogisticRegressionModel.load("wineModel");
        Dataset<Row> predictions = model.transform(finalData);

        MulticlassClassificationEvaluator evaluator = new MulticlassClassificationEvaluator()
                .setLabelCol("label")
                .setPredictionCol("prediction")
                .setMetricName("f1");

        double f1 = evaluator.evaluate(predictions);
        System.out.println("F1 Score = " + f1);

        spark.stop();
    }
}
